import{c as e,n as t,o as n,r}from"./aliases-BpAf03zb.js";var i=/姓名|名字|电话|手机|邮箱|身份证|证件|护照|住址|地址|家庭|父亲|母亲|配偶|紧急联系|银行|账号|账户|密码|宿舍|学号|工号|微信|QQ|籍贯|户口|出生|年龄|身高|体重|血型|婚|健康|病|残疾|薪|工资|期望月薪|推荐人|内推码/,a=`任务：网申页面上有一些问题，候选人的档案里没有现成答案。请依据候选人简历回答。
规则：
1. 文本题：正面回答，第一人称，简洁具体，只用简历里的经历。字数不超过上限（没写上限的短文本题 50 字内，多行文本题 200 字左右）。
2. 需要简历里没有的事实（具体数字、时间、个人情况）时，用【待补充：说明】标出，不要编。
3. 选择题：只能从给出的选项里原样选一个；看不出该选哪个就输出 null。
4. 涉及个人隐私或只有本人知道的问题（家庭、健康、薪资、证件、联系方式、是否有亲属在本公司等）一律输出 null。
只输出 JSON：{"answers":[{"id":序号,"answer":"回答或 null"}]}，不要输出别的文字。`,o={text:`短文本`,textarea:`多行文本`,choice:`选择题`};function s(e){let t=[`${e.id}. ${e.question}（${o[e.kind]}`];return e.limit>0&&t.push(`，不超过 ${e.limit} 字`),t.push(`）`),e.options.length&&t.push(` 选项：${e.options.slice(0,20).join(` / `)}`),t.join(``)}var c={id:`page-questions`,name:`回答网申页面上的问题`,temperature:.4,build:({questions:e,company:n,resume:r})=>[{role:`system`,content:`${t}\n\n${a}`},{role:`user`,content:[n&&`公司/岗位：${n}`,`候选人简历：\n${r}`,`问题：\n${e.map(s).join(`
`)}`].filter(Boolean).join(`

`)}],parse:(t,{questions:a})=>{let o=t??{},s=new Map(a.map(e=>[e.id,e])),c=[];for(let t of n(o.answers,100)){let n=s.get(Number(t.id)),a=e(t.answer,3e3);n&&a&&a!==`null`&&!c.some(e=>e.id===n.id)&&!i.test(n.question)&&(n.kind!==`choice`||n.options.includes(a))&&(n.limit>0&&r(a)>n.limit||c.push({id:n.id,answer:a}))}return c}};export{c as n,i as t};